package com.human.vo;

public class MoviesVO {
	private String m_name;
	private String m_content;
	private String m_country;
	private String m_genre;
	private int m_alimit;
	private String m_actor;
	private String m_director;
	private String m_date;
	private String m_time;
	private String m_filename;
	private String m_oneline;
	private int m_views;

	public int getM_views() {
		return m_views;
	}

	public void setM_views(int m_views) {
		this.m_views = m_views;
	}

	public String getM_oneline() {
		return m_oneline;
	}

	public void setM_oneline(String m_oneline) {
		this.m_oneline = m_oneline;
	}

	public String getM_name() {
		return m_name;
	}

	public void setM_name(String m_name) {
		this.m_name = m_name;
	}

	public String getM_content() {
		return m_content;
	}

	public void setM_content(String m_content) {
		this.m_content = m_content;
	}

	public String getM_country() {
		return m_country;
	}

	public void setM_country(String m_country) {
		this.m_country = m_country;
	}

	public String getM_genre() {
		return m_genre;
	}

	public void setM_genre(String m_genre) {
		this.m_genre = m_genre;
	}

	public int getM_alimit() {
		return m_alimit;
	}

	public void setM_alimit(int m_alimit) {
		this.m_alimit = m_alimit;
	}

	public String getM_actor() {
		return m_actor;
	}

	public void setM_actor(String m_actor) {
		this.m_actor = m_actor;
	}

	public String getM_director() {
		return m_director;
	}

	public void setM_director(String m_director) {
		this.m_director = m_director;
	}

	public String getM_date() {
		return m_date;
	}

	public void setM_date(String m_date) {
		this.m_date = m_date;
	}

	public String getM_time() {
		return m_time;
	}

	public void setM_time(String m_time) {
		this.m_time = m_time;
	}

	public String getM_filename() {
		return m_filename;
	}

	public void setM_filename(String m_filename) {
		this.m_filename = m_filename;
	}

}
