package com.human.vo;

public class UserVO {

	private String u_id;
	private String u_pw;
	private String u_birthdate;
	private String u_name;
	private String u_email;
	private String u_grade;
	private String u_addr;
	private String u_preferredgenre;
	private String favoriteMovieTheater;
	private String u_date;

	public String getU_date() {
		return u_date;
	}

	public void setU_date(String u_date) {
		this.u_date = u_date;
	}

	public String getFavoriteMovieTheater() {
		return favoriteMovieTheater;
	}

	public void setFavoriteMovieTheater(String favoriteMovieTheater) {
		this.favoriteMovieTheater = favoriteMovieTheater;
	}

	public String getU_addr() {
		return u_addr;
	}

	public void setU_addr(String u_addr) {
		this.u_addr = u_addr;
	}

	public String getU_preferredgenre() {
		return u_preferredgenre;
	}

	public void setU_preferredgenre(String u_preferredgenre) {
		this.u_preferredgenre = u_preferredgenre;
	}

	public String getU_grade() {
		return u_grade;
	}

	public void setU_grade(String u_grade) {
		this.u_grade = u_grade;
	}

	public String getU_email() {
		return u_email;
	}

	public void setU_email(String u_email) {
		this.u_email = u_email;
	}

	public String getU_id() {
		return u_id;
	}

	public void setU_id(String u_id) {
		this.u_id = u_id;
	}

	public String getU_pw() {
		return u_pw;
	}

	public void setU_pw(String u_pw) {
		this.u_pw = u_pw;
	}

	public String getU_birthdate() {
		return u_birthdate;
	}

	public void setU_birthdate(String u_birthdate) {
		this.u_birthdate = u_birthdate;
	}

	public String getU_name() {
		return u_name;
	}

	public void setU_name(String u_name) {
		this.u_name = u_name;
	}

}
