package com.human.vo;

public class m_commentVO {

	private String m_name;
	private String c_starPoint;
	private String c_comment;
	private String u_id;
	private String c_date;

	public String getM_name() {
		return m_name;
	}

	public void setM_name(String m_name) {
		this.m_name = m_name;
	}

	public String getC_starPoint() {
		return c_starPoint;
	}

	public void setC_starPoint(String c_starPoint) {
		this.c_starPoint = c_starPoint;
	}

	public String getC_comment() {
		return c_comment;
	}

	public void setC_comment(String c_comment) {
		this.c_comment = c_comment;
	}

	public String getU_id() {
		return u_id;
	}

	public void setU_id(String u_id) {
		this.u_id = u_id;
	}

	public String getC_date() {
		return c_date;
	}

	public void setC_date(String c_date) {
		this.c_date = c_date;
	}

}
